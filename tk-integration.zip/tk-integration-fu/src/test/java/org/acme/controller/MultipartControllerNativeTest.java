package org.acme.controller;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class  MultipartControllerNativeTest extends MultipartControllerTest {

    // Execute the same tests but in native mode.
}