package org.acme.controller;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class TKIntegrationControllerNativeTest extends TKIntegrationControllerTest {

    // Execute the same tests but in native mode.
}