package org.acme.controller;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class AuthControllerTestNativeTest extends AuthControllerTest {

    // Execute the same tests but in native mode.
}